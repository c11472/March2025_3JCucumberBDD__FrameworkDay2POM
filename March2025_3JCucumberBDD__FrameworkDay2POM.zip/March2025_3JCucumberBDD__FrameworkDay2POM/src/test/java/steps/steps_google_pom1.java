package steps;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import libraries.TestLib1;
import libraries2.TestLib2;


import io.cucumber.java.en.Given;
import libraries.TestLib1;
import libraries2.TestLib2;

public class steps_google_pom1 {
	WebDriver wd;
	
	// Page class objects
	TestLib1 l1 = new TestLib1(); // Home page
    TestLib2  l2 = new  TestLib2(); // Registration page
    
    @Before
    public void setup() {
    	wd=new FirefoxDriver(); // pre - setup
    }
	@Given("I am in awesomeqa homepage")
	public void launchapp() throws IOException {
	    l1.init1(wd);  // method call from page1
		l1.LaunchApp(); // method call from page2
	}

	@When("I click on MyAccount")
	public void enter_stringinp() {
		l1.click_ma(); // method call to click myaccount
		
			
	}
	
	@When("I click on register")
	public void register() {
		l1.Register_Link(); //call method -- page1
		
	}
	@When("I enter the first name")
	public void registrationpage() throws IOException {
		System.out.println("success");
		l2.init2(wd);
		l2.Extract_title();
		l2.Enter_FirstName();
	
		
	}
	
	@When("I enter the last name")
	public void lastName() throws IOException {
		l2.Enter_LastName();
		
	}
	@When("I enter the email")
	public void emailAdd() throws IOException {
		l2.Enter_Email();
	}
	
	/*@Given
	@When
	@When
	@Then
	
	@Given
	@When
	@When
	@Then
	@Given
	@When
	@When
	@Then
	
	@Given
	@When
	@When
	@Then*/
	
	
	
	
	/*
	@After
	public void Close_Browser_Instance() {
		wd.close();
	}
	*/
	

		  
	   
}
