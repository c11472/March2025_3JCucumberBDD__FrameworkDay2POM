import org.testng.annotations.Test;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features = "src/test/java/FeatureFileForPOM",
 // Makes the console output more readable
glue = "steps",tags="@tag1 or @tag2 or @tag3 or @tag4",
plugin={"pretty","html:target/TestReports/module1.html"},
monochrome = true, // Makes the console output more readable
dryRun = false )

public class testruntest1 extends AbstractTestNGCucumberTests 
{
	
}
