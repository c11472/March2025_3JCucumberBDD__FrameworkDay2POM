
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
//set the path folder of feature files
features="src\\test\\java\\FeatureFileForPOM",
// set the folder name for stepsdeinition files
glue={"steps"},
//console output will be much more readable
monochrome=true,
//specify the report format
plugin={"pretty","html:target/HTMLReportTest/newtestreport1.html",
		"json:target/JsonReport/report2.json",
		"junit:target/XmlReport/report3.xml"},
tags= "@tag1 or @tag3"
)

public class runnertest {
	//just an empty class template

}
