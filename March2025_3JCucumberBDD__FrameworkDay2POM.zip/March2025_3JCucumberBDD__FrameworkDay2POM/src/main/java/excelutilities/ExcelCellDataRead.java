package excelutilities;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.google.common.io.Files;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ExcelCellDataRead {
    String filePath = "./TestData/data1.xlsx";

	    
	    public String ReadFirstName() throws IOException {
	      //  String filePath = "./TestData/data1.xlsx";

	        // Create an input stream for the Excel file
	        FileInputStream fileInputStream = new FileInputStream(new File(filePath));

	        // Create a workbook instance
	        Workbook workbook = new XSSFWorkbook(fileInputStream);//1
	        

	        // Get the first sheet from the workbook
	        Sheet sheet = workbook.getSheetAt(0); //2

	        // Specify the row and cell you want to read
	        int rowIndex = 1; // Row index (0-based, so row 1 is actually index 0)
	        int cellIndex = 0; // Cell index (0-based, so cell 2 is actually index 1)

	        // Get the specific row from the sheet
	        Row row = sheet.getRow(rowIndex); // which row  0----n-1---1 //3
	        
            Cell cell = row.getCell(cellIndex); //2[1,2]
            
            String fnm = cell.getStringCellValue();
            return fnm; // returns firstname from Excel sheet
	    }
	    
	    public String ReadLastName() throws IOException {
	        //String filePath = "./TestData/data1.xlsx";

	        // Create an input stream for the Excel file
	        FileInputStream fileInputStream1 = new FileInputStream(new File(filePath));

	        // Create a workbook instance
	        Workbook workbook1 = new XSSFWorkbook(fileInputStream1);

	        // Get the first sheet from the workbook
	        Sheet sheet = workbook1.getSheetAt(0);

	        // Specify the row and cell you want to read
	        int rowIndex = 1; // Row index (0-based, so row 1 is actually index 0)
	        int cellIndex = 1; // Cell index (0-based, so cell 2 is actually index 1)

	        // Get the specific row from the sheet
	        Row row1 = sheet.getRow(rowIndex);
            Cell cell1 = row1.getCell(cellIndex);
            
            String  lnm = cell1.getStringCellValue();
            return lnm; // returns lastname


	        

	    }
	    
	    
	    public String ReadEmail() throws IOException {
	        //String filePath = "./TestData/data1.xlsx";

	        // Create an input stream for the Excel file
	        FileInputStream fileInputStream2 = new FileInputStream(new File(filePath));

	        // Create a workbook instance
	        Workbook workbook2 = new XSSFWorkbook(fileInputStream2);

	        // Get the first sheet from the workbook
	        Sheet sheet = workbook2.getSheetAt(0);

	        // Specify the row and cell you want to read
	        int rowIndex = 1; // Row index (0-based, so row 1 is actually index 0)
	        int cellIndex = 2; // Cell index (0-based, so cell 2 is actually index 1)

	        // Get the specific row from the sheet
	        Row row1 = sheet.getRow(rowIndex);
            Cell cell1 = row1.getCell(cellIndex);
            
            String  eml = cell1.getStringCellValue();
            return eml; // return email from excel sheet


	        

	    }
	    
	  


	}



