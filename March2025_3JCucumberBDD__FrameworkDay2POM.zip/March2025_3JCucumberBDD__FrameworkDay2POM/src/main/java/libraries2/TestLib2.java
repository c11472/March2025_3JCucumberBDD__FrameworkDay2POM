package libraries2;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.Files;

import excelutilities.ExcelCellDataRead;


public class TestLib2 extends ExcelCellDataRead {
	// Excel Class object
	ExcelCellDataRead excell = new ExcelCellDataRead();
	
    WebDriver wd;
	
	public void init2(WebDriver wd) {
		this.wd = wd;
		
	}  
	
	By firstName = By.name("firstname");
	By lastName = By.name("lastname");
	By eml1 = By.name("email");

	
	
	public void Extract_title() {
		    String title = wd.getTitle();
			System.out.println(title);
	}
	
	public void Enter_FirstName() throws IOException {
		
		String firstName1=excell.ReadFirstName();
		System.out.println("The first name is " + " "+ firstName1);
		wd.findElement(firstName).sendKeys(firstName1); // No hard-code
		
	}
	
	public void Enter_LastName() throws IOException {
		String LstName1 = excell.ReadLastName();
		System.out.println("The last name is " + " "+ LstName1);

		wd.findElement(lastName).sendKeys(LstName1); // No hard-code
		
	}
	
	public void Enter_Email() throws IOException {
		String Email1 = excell.ReadEmail();
		System.out.println("The email is " + " "+ Email1);

		wd.findElement(eml1).sendKeys(Email1); // No hard-code
		
		File src3 = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
	  	Files.copy(src3, new File("./ScreenShots/testsrc1.png"));		
         // method call
	}
	
	
	
	
}
