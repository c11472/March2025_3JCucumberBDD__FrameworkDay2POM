package libraries;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class TestLib1 {
	
	WebDriver wd;
	//By variables for storing the loactors info
	
	Properties P;
	FileReader File1;
	
	By myacc = By.xpath("//*[@id='top-links']/ul/li[2]/a/span[2]");
	
	public void init1(WebDriver wd)  {
		this.wd = wd;
		
		
	}
	public void LaunchApp() throws IOException {
		File1 = new FileReader("./ConfigDetails/configfile.properties");
		P = new Properties();
		P.load(File1);
		wd.get(P.getProperty("BaseURL")); // Taking the data from config.properties
	}
	//change
	public void click_ma() {
		wd.findElement(myacc).click(); // please follow this 
		//wd.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/span[2]")).click();
	}
	
	public void Register_Link() {
		wd.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[1]/a")).click();
	}
	
	public void Login_Link() {
		wd.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[2]/a")).click();
		
	}
	
		
	// No asserts are there
	// add assertions for each critical steps
	
}
